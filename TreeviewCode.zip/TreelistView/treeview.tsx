import * as React from "react";
import {
  TreeList,
  TreeListToolbar,
  mapTree,
  extendDataItem,
  removeItems,
  modifySubItems,
  TreeListColumnProps,
  filterBy,
  TreeListTextFilter,
  TreeListPageChangeEvent,
  mapTreeItem,
  TreeListTextEditor,
  TreeListBooleanEditor,
  TreeListItemChangeEvent,
  TreeListExpandChangeEvent,
  TreeListFilterChangeEvent,
  TreeListBooleanFilter,
  TreeListDateFilter,
  TreeListDateEditor,
  TreeListRowClickEvent,
  TreeListRowProps,
} from "@progress/kendo-react-treelist";
import { Customer, SupplyInfo } from "./treeviewFiles/interfaces";
import { FilterDescriptor } from "@progress/kendo-data-query";
import { TreeListPager } from "./treeviewFiles/pager";
import TreeviewCommandsCell from "./treeviewFiles/TreeviewCommands";
import { IInputs } from "./generated/ManifestTypes";
import DropDownCellFunc from "./treeviewFiles/DropdownCell";
import { confirmAlert } from "react-confirm-alert";
import DropDownFilter, { filterProps } from "./treeviewFiles/DropDownFilter";
import { Renderers } from "./treeviewFiles/InCellRenderers";
import TextCellFunc from "./treeviewFiles/CustomTextCell";
import DatePickerCell from "./treeviewFiles/DatePickerCell";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { GridLayout, GridLayoutItem } from "@progress/kendo-react-layout";
import { Label } from "@progress/kendo-react-labels";
import {
  Input,
  InputChangeEvent,
  TextArea,
} from "@progress/kendo-react-inputs";
import {
  DropDownList,
  DropDownListChangeEvent,
} from "@progress/kendo-react-dropdowns";
import Tooltip from "./treeviewFiles/Tooltip";
import { Popover } from "@progress/kendo-react-tooltip";
import { Button } from "@progress/kendo-react-buttons";
import TootlTipPopup from "./treeviewFiles/Tooltip";
import EditCheckBox from "./treeviewFiles/EditCheckBoxCell";
import BulkEditWindow, { IBulkEditState } from "./treeviewFiles/BulkEdit";

const subItemsField: string = "customers";
const expandField: string = "expanded";
const editField: string = "inEdit";

interface IModelPopupData {
  reason?: string;
  criticality?: string;
  description?: string;
  pastresolutioncomments?: string;
  recordGuid?: string;
  visibleModelPopup: boolean;
  anyError: boolean;
  errorText?: string;
}
interface IToolTipInfo {
  showToolTip?: boolean;
  element?: any;
}

interface IBulkEditInfo {
  showWindow?: boolean;
  bulkEditGuids?: string[];
  bulkEditBtndisable?: boolean;
  isFromBulkEdit?: boolean;
}
interface AppState extends IModelPopupData, IToolTipInfo, IBulkEditInfo {
  data: Customer[];
  expanded: string[];
  inEdit: Array<{ guid: string; isNew: boolean }>;
  filter: FilterDescriptor[];
  skip: number;
  take: number;
  filterDropDownValue: string;
  editItem: Customer | undefined;
  editItemField: string | undefined;
  changes: boolean;
  filterDropDownValueOfAppType: string;
  filterDropDownValueOfCriticality: string;
  editId: string | null;
  inEditForBulk: string[];
}

export interface IAppProps {
  context: ComponentFramework.Context<IInputs>;
}

export class App extends React.Component<IAppProps, AppState> {
  private _context: ComponentFramework.Context<IInputs>;
  private gridData: Customer[] = new Array();
  private gridDataCopy: Customer[] = new Array();
  private isFound = false;
  private foundRecord: Customer | undefined;
  private _emptyGuid: string = "00000000-0000-0000-0000-000000000000";
  anchor: any = React.createRef();

  private dropdownValues: string[] = [
    "Not Started",
    "Started",
    "In Progress",
    "About to Complete",
    "Completed",
    "Off Track",
    "Risk",
  ];

  private statusDropdownValues = [
    { text: "Not Started", value: "132520000" },
    { text: "Started", value: "132520001" },
    { text: "In Progress", value: "132520002" },
    { text: "About to Complete", value: "132520003" },
    { text: "Completed", value: "132520004" },
    { text: "Off Track", value: "132520005" },
    { text: "Risk", value: "132520006" },
  ];

  private appTypeDropdownValues = [
    { text: "Application Type 1", value: "132520000" },
    { text: "Application Type 2", value: "132520001" },
  ];

  private criticalityDropdownValues = [
    { text: "High", value: "132520000" },
    { text: "Low", value: "132520001" },
    { text: "Medium", value: "132520002" },
  ];

  textBoxCell = TextCellFunc();
  descriptionTextBoxCell = TextCellFunc();
  reasonTextBoxCell = TextCellFunc();
  pastresolutioncommentsTextBoxCell = TextCellFunc();

  constructor(props: IAppProps) {
    super(props);
    this.state = {
      data: [],
      expanded: [],
      inEdit: [],
      filter: [],
      skip: 0,
      take: 8,
      filterDropDownValue: "Select..",
      editItem: undefined,
      editItemField: undefined,
      changes: false,
      filterDropDownValueOfAppType: "Select..",
      filterDropDownValueOfCriticality: "Select..",
      editId: null,
      visibleModelPopup: false,
      anyError: false,
      showToolTip: false,
      inEditForBulk: [],
      showWindow: false,
      bulkEditBtndisable: true,
      isFromBulkEdit: false,
    };
    this._context = this.props.context;
  }

  rowClick = (event: TreeListRowClickEvent) => {
    let allValidationsPassedforcurrentRecord: boolean | undefined =
      this.checkAllValidationsPassed();

    let stateObj: any;
    let editid = null;
    let editItem;
    if (this.state.editId === event.dataItem.guid) {
      if (
        allValidationsPassedforcurrentRecord === undefined ||
        allValidationsPassedforcurrentRecord
      ) {
        editid = null;
        stateObj = { ...this.state, editId: editid };
      } else {
        editid = event.dataItem.guid;
        stateObj = {
          ...this.state,
          editId: editid,
          inEdit: [...this.state.inEdit, event.dataItem],
        };
      }
    } else {
      if (allValidationsPassedforcurrentRecord === false) {
        editid = this.state.editId;
        stateObj = { ...this.state, editId: editid };
      } else {
        editid = event.dataItem.guid;
        stateObj = {
          ...this.state,
          editId: editid,
          inEdit: [...this.state.inEdit, event.dataItem],
        };
      }
    }

    const val: string = event.dataItem.statusValue.toString();
    let evv: TreeListItemChangeEvent = {
      dataItem: event.dataItem,
      level: event.level,
      nativeEvent: event.nativeEvent,
      syntheticEvent: event.syntheticEvent,
      field: "status",
      value: { text: event.dataItem.status, value: val },
      target: event.target,
    };

    let canPopupbeShown = false;
    let ed: any;

    const mtree = mapTree(this.state.data, subItemsField, (item) => {
      if (item.guid === event.dataItem.guid) {
        if (evv.field === "status") {
          let percentageCompleted = 0;
          switch (evv.value.value) {
            case "132520000":
              percentageCompleted = 0;
              break;
            case "132520001":
              percentageCompleted = 25;
              break;
            case "132520002":
              percentageCompleted = 50;
              break;
            case "132520003":
              percentageCompleted = 75;
              break;
            case "132520004":
              percentageCompleted = 100;
              break;
          }
          if (
            evv.value.value === "132520005" ||
            evv.value.value === "132520006"
          ) {
            canPopupbeShown = true;
          }
          const nameValue: string = event.dataItem["name"];
          const appTypeValue: string = event.dataItem["applicationType"];
          const reasonValue: string = event.dataItem["reason"];
          const criticalityValue: string = event.dataItem["criticality"];
          const descriptionValue: string = event.dataItem["description"];
          const pastresolutioncommentsValue: string =
            event.dataItem["pastresolutioncomments"];
          const startDateValue: Date = event.dataItem["startDate"];
          const completedOnValue: Date = event.dataItem["completedOn"];

          ed = this.ValidateCell(
            evv.field,
            evv.value,
            nameValue,
            evv.dataItem,
            percentageCompleted,
            "name"
          );

          ed = this.ValidateCell(
            evv.field,
            evv.value,
            startDateValue,
            ed,
            percentageCompleted,
            "startDate"
          );

          ed = this.ValidateCell(
            evv.field,
            evv.value,
            completedOnValue,
            ed,
            percentageCompleted,
            "completedOn"
          );

          ed = this.ValidateCell(
            evv.field,
            evv.value,
            appTypeValue,
            ed,
            percentageCompleted,
            "applicationType"
          );

          ed = this.ValidateCell(
            evv.field,
            evv.value,
            reasonValue,
            ed,
            percentageCompleted,
            "reason"
          );

          ed = this.ValidateCell(
            evv.field,
            evv.value,
            criticalityValue,
            ed,
            percentageCompleted,
            "criticality"
          );
          ed = this.ValidateCell(
            evv.field,
            evv.value,
            descriptionValue,
            ed,
            percentageCompleted,
            "description"
          );
          ed = this.ValidateCell(
            evv.field,
            evv.value,
            pastresolutioncommentsValue,
            ed,
            percentageCompleted,
            "pastresolutioncomments"
          );

          return ed;
        }

        return item;
      }
      return item;
    });

    stateObj["data"] = mtree;
    this.setState(stateObj);
  };
  dropdownFilter = (props: any) => (
    <DropDownFilter
      {...props}
      data={this.dropdownValues}
      handleFilterChangeFunc={this.handleDropdownFilterChange}
      valueText={this.state.filterDropDownValue}
      defaultItem="Select.."
    />
  );

  appTypeDropdownFilter = (props: any) => {
    let appTypesText: string[] = [];
    this.appTypeDropdownValues.forEach((each: any) => {
      appTypesText.push(each.text);
    });

    return (
      <DropDownFilter
        {...props}
        data={appTypesText}
        handleFilterChangeFunc={this.handleAppTypeDropdownFilterChange}
        valueText={this.state.filterDropDownValueOfAppType}
        defaultItem="Select.."
      />
    );
  };

  criticalityDropdownFilter = (props: any) => {
    let criticalityText: string[] = [];
    this.criticalityDropdownValues.forEach((each: any) => {
      criticalityText.push(each.text);
    });

    return (
      <DropDownFilter
        {...props}
        data={criticalityText}
        handleFilterChangeFunc={this.handleCriticalityDropdownFilterChange}
        valueText={this.state.filterDropDownValueOfCriticality}
        defaultItem="Select.."
      />
    );
  };

  checkAllValidationsPassed = () => {
    if (this.state.isFromBulkEdit === true) {
      return true;
    }

    let allValidationsPassedforcurrentRecord: boolean | undefined = undefined;

    let foundArr: any = [];
    if (this.state.editId) {
      foundArr = this.FindAndGetDataItemFromTreeByGuid(
        this.state.data,
        "guid",
        this.state.editId
      );
    }
    // const indx = this.state.data.findIndex(
    //   (e: Customer) => this.state.editId && e.guid === this.state.editId
    // );
    if (foundArr.length > 0) {
      const selectedRowDataItem = foundArr[0]; // this.state.data[indx];
      if (
        selectedRowDataItem.performValidation &&
        selectedRowDataItem.performValidation.length > 0
      ) {
        const validationIndx = selectedRowDataItem.performValidation.findIndex(
          (eachField: any) => {
            return eachField.IsValidationpassed === false;
          }
        );

        allValidationsPassedforcurrentRecord = validationIndx === -1;
      }
    }

    return allValidationsPassedforcurrentRecord;
  };

  async componentDidMount() {
    console.log("process data started");
    await this.LoadTreeList();
    console.log("process data End");
  }

  private async LoadTreeList() {
    let allChildGuidsLvl1: string[] = [];
    let allChildGuidsLvl2: string[] = [];
    let allChildGuidsLvl3: string[] = [];
    let allChildGuidsLvl4: string[] = [];

    const { gridData, expandedRowsArray } = await this.getDataFromCRM();
    this.setState(
      {
        data: gridData,
      },
      async () => {
        let rowIds: any = [];
        let parentRowIds: any = [];
        allChildGuidsLvl2 = await new Promise((resolve) => {
          gridData.forEach(async (eachParent: any, indx, array) => {
            //Parent Ids as level 1
            parentRowIds = [...parentRowIds, eachParent.guid];
            let ids: any = await this.getChildDataFromCRM(eachParent.guid, []);
            if (ids.length > 0) {
              rowIds = [...rowIds, ...ids];
            }
            if (indx === array.length - 1) {
              resolve(rowIds);
            }
          });
        });
        console.log("parentRowIds");
        console.log(parentRowIds);

        console.log("allChildGuidsLvl2");
        console.log(allChildGuidsLvl2);
        rowIds = [];
        allChildGuidsLvl3 = await new Promise((resolve) => {
          allChildGuidsLvl2.forEach(
            async (eachParent: any, indx: any, array: any) => {
              let ids: any = await this.getChildDataFromCRM(eachParent, []);
              if (ids.length > 0) {
                rowIds = [...rowIds, ...ids];
              }

              if (indx === array.length - 1) {
                resolve(rowIds);
              }
            }
          );
        });
        console.log("allChildGuidsLvl3");
        console.log(allChildGuidsLvl3);

        rowIds = [];
        await new Promise((resolve) => {
          allChildGuidsLvl3.forEach(
            async (eachParent: any, indx: any, array: any) => {
              let ids: any = await this.getChildDataFromCRM(eachParent, []);
              // if (ids.length > 0) {
              //   rowIds = [...rowIds, ...ids];
              // }
              if (indx === array.length - 1) {
                resolve([rowIds]);
              }
            }
          );
        }).then((res) => {
          console.log("setting expand");
          this.setState(
            {
              expanded: [
                ...parentRowIds,
                ...allChildGuidsLvl2,
                ...allChildGuidsLvl3,
                // ...allChildGuidsLvl4,
              ],
            },
            () => {
              console.log("Expanded rows");
              console.log(this.state.expanded);
            }
          );
        });
      }
    );
  }

  private async ExpandAllChilds(eachParent: string) {
    return new Promise((resolve) => {
      let allChildGuids: string[] = [];
      this.getChildDataFromCRM(eachParent, []).then((childGuids: any) => {
        if (childGuids && childGuids.length > 0) {
          allChildGuids = [...allChildGuids, ...childGuids];
        }

        resolve(allChildGuids);
      });
    });
  }

  async getDataFromCRM() {
    // this.PrepareTestData();
    // return this.gridData;
    console.log("getDataFromCRM");
    //return new Promise((resolve, reject) => {
    const fetchXmlQuery = `<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
    <entity name='cr08d_customer'>
      <attribute name='cr08d_customerid' />
      <attribute name='cr08d_name' />
      <attribute name='cr08d_status' />
      <attribute name='cr08d_completedon' />
      <attribute name='cr08d_percentagecompleted' />
      <attribute name='cr08d_parentid' />
      <attribute name='cr08d_startdate' />
      <attribute name='cr08d_reason' />
      <attribute name='cr08d_pastresolutioncomments' />
      <attribute name='cr08d_description' />
      <attribute name='cr08d_criticality' />
      <attribute name='cr08d_applicationtype' />
    <filter type='and'>
      <condition attribute='cr08d_parentid' operator='null' />
    </filter>
    <link-entity name='cr08d_supplyinformation' from='cr08d_projectid' to='cr08d_customerid' link-type='outer' alias='supplyInfo'>
    <attribute name='cr08d_supplyinformationid' />
    <attribute name='modifiedon' />
   <attribute name='cr08d_modifiedcomments' />
   <attribute name='cr08d_crnumber' />
     <attribute name='cr08d_approvaldate' />
        </link-entity>
    </entity>
  </fetch>`;

    const responses = await this._context.webAPI.retrieveMultipleRecords(
      "cr08d_customer",
      "?fetchXml=" + fetchXmlQuery
    );
    //.then((responses) => {
    console.log("Next Link " + responses.nextLink);
    console.log("Records " + responses.entities);

    let supplyInfoData: SupplyInfo[] = [];
    let expandedRows: string[] = [];

    responses.entities.forEach((eachRecord) => {
      console.log(eachRecord);
      //"2022-07-11T00:00:00Z"
      console.log(eachRecord.cr08d_startdate);
      console.log(eachRecord.cr08d_completedon);

      supplyInfoData = [];
      this.PrepareSupplyInfo(eachRecord, supplyInfoData);
      console.log("after PrepareSupplyInfo. supplyInfoData below");
      console.log(supplyInfoData);

      const indx = this.gridData.findIndex((record: Customer) => {
        return record.guid === eachRecord.cr08d_customerid;
      });

      if (indx !== -1) {
        console.log("already parent exist in array");
        let existingRecord = this.gridData[indx];
        if (existingRecord.supplyInfo) {
          if (existingRecord.supplyInfo.length === 0) {
            existingRecord.supplyInfo = [...supplyInfoData];
          } else {
            existingRecord.supplyInfo.push(supplyInfoData[0]);
          }
        }
        console.log("after suuply info updated to exisitng record.");
        console.log(existingRecord);
      } else {
        console.log("new Parent");
        const completedOnDateString: string = eachRecord.cr08d_completedon;
        const startDateString: string = eachRecord.cr08d_startdate;
        const newDate = completedOnDateString
          ? this.GetDate(completedOnDateString)
          : new Date();
        const newStartDate = startDateString
          ? this.GetDate(startDateString)
          : new Date();

        let eachRow: Customer = {
          guid: eachRecord.cr08d_customerid,
          status:
            eachRecord[
              "cr08d_status@OData.Community.Display.V1.FormattedValue"
            ],
          statusValue: eachRecord.cr08d_status,
          completedOn: newDate, //.cr08d_completedon,
          percentageCompleted:
            eachRecord[
              "cr08d_percentagecompleted@OData.Community.Display.V1.FormattedValue"
            ],
          customers: [{ guid: this._emptyGuid }],
          name: eachRecord.cr08d_name,
          startDate: newStartDate,
          applicationType:
            eachRecord[
              "cr08d_applicationtype@OData.Community.Display.V1.FormattedValue"
            ],
          applicationTypeValue: eachRecord.cr08d_applicationtype,
          criticality:
            eachRecord[
              "cr08d_criticality@OData.Community.Display.V1.FormattedValue"
            ],
          criticalityValue: eachRecord.cr08d_criticality,
          description: eachRecord.cr08d_description,
          reason: eachRecord.cr08d_reason,
          pastresolutioncomments: eachRecord.cr08d_pastresolutioncomments,
          supplyInfo: supplyInfoData,
        };
        console.log(eachRow);

        if (indx === -1) {
          console.log("pushing record.");
          this.gridData.push(eachRow);
          expandedRows.push(eachRow.guid);
        }
      }
    });

    console.log("expanded rows");
    console.log(expandedRows);
    this.gridDataCopy = this.gridData;
    console.log("data before return");
    console.log(this.gridData);
    return { gridData: this.gridData, expandedRowsArray: expandedRows };
  }

  private PrepareTestData() {
    let sidata: SupplyInfo[] = [
      {
        guid: "0FC73D60-2B0E-ED11-B83E-000D3AF21240",
        parentGuid: "05a231d3-ce00-ed11-82e6-000d3af21240",
        supplyInfoComments: "2020July",
        supplyInfoModifiedOn: new Date(2020, 6, 29),
      },
      {
        guid: "21EE0077-2B0E-ED11-B83E-000D3AF21240",
        parentGuid: "05a231d3-ce00-ed11-82e6-000d3af21240",
        supplyInfoComments: "2022Jan",
        supplyInfoModifiedOn: new Date(2022, 0, 20),
      },
      {
        guid: "21EE0077-2B0E-ED11-B83E-000D3AF21240",
        parentGuid: "05a231d3-ce00-ed11-82e6-000d3af21240",
        supplyInfoComments: "2021Nov",
        supplyInfoModifiedOn: new Date(2021, 10, 10),
      },
    ];

    let childRow: Customer = {
      guid: "FE472828-D405-ED11-82E6-000D3AF21240",
      status: "Completed",
      statusValue: "132520004",
      completedOn: new Date(),
      percentageCompleted: 100,
      customers: [{ guid: this._emptyGuid }],
      name: "test",
      applicationType: "Application Type 1",
      applicationTypeValue: "132520000",
      criticality: "High",
      criticalityValue: "132520000",
      description: "Descr",
      reason: "reason",
      startDate: new Date(),
      pastresolutioncomments: "Comments",
      supplyInfo: sidata,
    };
    let eachRow: Customer = {
      guid: "05a231d3-ce00-ed11-82e6-000d3af21240",
      status: "Completed",
      statusValue: "132520004",
      completedOn: new Date(),
      percentageCompleted: 100,
      customers: [childRow],
      name: "test",
      applicationType: "Application Type 1",
      applicationTypeValue: "132520000",
      criticality: "High",
      criticalityValue: "132520000",
      description: "Descr",
      reason: "reason",
      startDate: new Date(),
      pastresolutioncomments: "Comments",
      supplyInfo: sidata,
    };

    let eachRow2: Customer = {
      guid: "67E8CCC2-5A03-ED11-82E6-000D3AF21240",
      status: "Completed",
      statusValue: "132520004",
      completedOn: new Date(),
      percentageCompleted: 100,
      customers: [{ guid: this._emptyGuid }],
      name: "test",
      applicationType: "Application Type 1",
      applicationTypeValue: "132520000",
      criticality: "High",
      criticalityValue: "132520000",
      description: "Descr",
      reason: "reason",
      startDate: new Date(),
      pastresolutioncomments: "Comments",
      supplyInfo: [],
    };

    this.gridData.push(eachRow);
    this.gridData.push(eachRow2);

    this.gridDataCopy = this.gridData;
  }

  private PrepareSupplyInfo(
    eachRecord: ComponentFramework.WebApi.Entity,
    supplyInfo: SupplyInfo[]
  ) {
    console.log("PrepareSupplyInfo started.");
    let supplyInfoObj: SupplyInfo = {};
    supplyInfoObj.parentGuid = eachRecord.cr08d_customerid;

    let supplyInfoModifiedDate: Date | undefined;
    if (eachRecord["supplyInfo.modifiedon"]) {
      const supplyInfoModifiedDateString: string =
        eachRecord["supplyInfo.modifiedon"];
      supplyInfoModifiedDate = this.GetDate(supplyInfoModifiedDateString);
    }

    let supplyInfoApprovalDate: Date | undefined;
    if (eachRecord["supplyInfo.cr08d_approvaldate"]) {
      const supplyInfoApprovalDateString: string =
        eachRecord["supplyInfo.cr08d_approvaldate"];
      supplyInfoApprovalDate = this.GetDate(supplyInfoApprovalDateString);
    }

    let supplyInfoCRNumber: string | undefined;
    if (eachRecord["supplyInfo.cr08d_crnumber"]) {
      const crNumber: string = eachRecord["supplyInfo.cr08d_crnumber"];
      supplyInfoCRNumber = crNumber;
    }

    let supplyInfoModifiedcomments: string | undefined;
    if (eachRecord["supplyInfo.cr08d_modifiedcomments"]) {
      const modifiedcomments: string =
        eachRecord["supplyInfo.cr08d_modifiedcomments"];
      supplyInfoModifiedcomments = modifiedcomments;
    }

    let supplyInfoGuid: string | undefined;
    if (eachRecord["supplyInfo.cr08d_supplyinformationid"]) {
      const guid: string = eachRecord["supplyInfo.cr08d_supplyinformationid"];
      supplyInfoGuid = guid;
    }

    supplyInfoObj.supplyInfoComments = supplyInfoModifiedcomments;
    supplyInfoObj.supplyInfoModifiedOn = supplyInfoModifiedDate;
    supplyInfoObj.approvalDate = supplyInfoApprovalDate;
    supplyInfoObj.guid = supplyInfoGuid;
    supplyInfoObj.crNumber = supplyInfoCRNumber
      ? parseInt(supplyInfoCRNumber)
      : undefined;

    const siIndx = supplyInfo.findIndex((eachSI: SupplyInfo) => {
      return eachSI.parentGuid === eachRecord.cr08d_customerid;
    });

    if (siIndx === -1) {
      supplyInfo.push(supplyInfoObj);
    } else {
      supplyInfo[siIndx] = supplyInfoObj;
    }
    console.log(supplyInfo);
    console.log("PrepareSupplyInfo end.");
  }

  private GetDate(completedOnDateString: string) {
    const tIndex = completedOnDateString.indexOf("T");
    const onlyDate = completedOnDateString.substring(0, tIndex);
    const dateValues = onlyDate.split("-");
    const year: number = parseInt(dateValues[0]);
    const month: number = parseInt(dateValues[1]);
    const day: number = parseInt(dateValues[2]);

    const utcDate = Date.UTC(year, month, day);
    console.log(utcDate);
    const newDate = new Date(completedOnDateString);
    console.log(newDate);
    return newDate;
  }

  FindAndGetDataItemFromTreeByGuid = (
    data: Customer[],
    field: string,
    value: string
  ) => {
    console.log("FindAndGetDataItemFromTreeByGuid start");
    let filter: any[] = [];
    filter.push({ value: value, field: field, operator: "eq" });
    //filter.push({ value: "15Hyacinth Hood1", field: "name", operator: "eq" });
    let dataforFiltering: any = data;

    do {
      dataforFiltering = filterBy(dataforFiltering, filter, subItemsField);
      if (dataforFiltering.length > 0 && dataforFiltering[0].customers) {
        dataforFiltering =
          dataforFiltering[0].guid !== value && dataforFiltering[0].customers;
      }
    } while (
      dataforFiltering.length !== 0 &&
      dataforFiltering[0].guid !== value
    );
    console.log(dataforFiltering);
    console.log("FindAndGetDataItemFromTreeByGuid end");
    return dataforFiltering;
  };
  async getChildDataFromCRM(parentId: string, treeLevel: number[]) {
    console.log("getChildDataFromCRM");
    //return new Promise((resolve, reject) => {
    let fetchXmlQuery = `<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
    <entity name='cr08d_customer'>
      <attribute name='cr08d_customerid' />
      <attribute name='cr08d_name' />
      <attribute name='cr08d_status' />
      <attribute name='cr08d_completedon' />
      <attribute name='cr08d_percentagecompleted' />
      <attribute name='cr08d_parentid' />
      <attribute name='cr08d_startdate' />
      <attribute name='cr08d_reason' />
      <attribute name='cr08d_pastresolutioncomments' />
      <attribute name='cr08d_description' />
      <attribute name='cr08d_criticality' />
      <attribute name='cr08d_applicationtype' />
      <order attribute='createdon' descending='true' />
      <filter type='and'>
        <condition attribute='cr08d_parentid' operator='eq' value='{0}' />
      </filter>
      <link-entity name='cr08d_supplyinformation' from='cr08d_projectid' to='cr08d_customerid' link-type='outer' alias='supplyInfo'>
      <attribute name='cr08d_supplyinformationid' />
      <attribute name='modifiedon' />
     <attribute name='cr08d_modifiedcomments' />
     <attribute name='cr08d_crnumber' />
     <attribute name='cr08d_approvaldate' />
          </link-entity>
    </entity>
  </fetch>`;

    fetchXmlQuery = fetchXmlQuery.replace("{0}", parentId);
    const responses = await this._context.webAPI.retrieveMultipleRecords(
      "cr08d_customer",
      "?fetchXml=" + fetchXmlQuery
    );
    //.then((responses) => {
    console.log("Next Link " + responses.nextLink);
    console.log("Records " + responses.entities);
    let childRecord: Customer;
    let childGuidArray: string[] = [];
    return new Promise((parentResolve) => {
      var pr = new Promise((resolve) => {
        if (responses.entities.length === 0) {
          let newData = modifySubItems(
            this.state.data,
            subItemsField,
            (item) => {
              return item.guid === parentId;
            },
            (subItems) => {
              let emptyChilds: Customer[] = [];
              return emptyChilds;
            }
          );

          this.setState({
            ...this.state,
            data: newData,
          });
          resolve(newData);
          return;
        }

        //clear all sub items
        let dataAfterSubItemCleared = modifySubItems(
          this.state.data,
          subItemsField,
          (item) => {
            return item.guid === parentId;
          },
          (subItems) => {
            let emptyChilds: Customer[] = [];
            return emptyChilds;
          }
        );
        let newData = dataAfterSubItemCleared; //this.state.data;

        let supplyInfoData: SupplyInfo[] = [];

        responses.entities.forEach((eachRecord, indx, array) => {
          //let eachRecord = responses.entities[0];
          console.log("Child record");
          console.log(eachRecord);
          //"2022-07-11T00:00:00Z"

          supplyInfoData = [];
          this.PrepareSupplyInfo(eachRecord, supplyInfoData);
          console.log("after PrepareSupplyInfo. supplyInfoData below");
          console.log(supplyInfoData);
          let newDataCopy = newData.map((e) => ({ ...e }));
          console.log("new data copy");
          console.log(newDataCopy);
          const filteredData = this.FindAndGetDataItemFromTreeByGuid(
            newDataCopy,
            "guid",
            eachRecord.cr08d_customerid
          );
          if (filteredData.length > 0) {
            newData = mapTree(newData, subItemsField, (item) => {
              if (item.guid === filteredData[0].guid) {
                let supplyInfoArray = [];
                if (item.supplyInfo.length === 0) {
                  supplyInfoArray = [...supplyInfoData];
                } else {
                  supplyInfoArray.push(supplyInfoData);
                }
                return extendDataItem(item, subItemsField, {
                  ["supplyInfo"]: supplyInfoArray,
                });
              }
              return item;
            });
            resolve(newData);
          } else {
            const completedOnDateString: string = eachRecord.cr08d_completedon;
            const newDate = completedOnDateString
              ? this.GetDateByYMD(completedOnDateString)
              : undefined;

            const startDateString: string = eachRecord.cr08d_startdate;
            const newStartDate = startDateString
              ? this.GetDateByYMDWithoutT(startDateString)
              : undefined;

            childRecord = {
              guid: eachRecord.cr08d_customerid,
              status:
                eachRecord[
                  "cr08d_status@OData.Community.Display.V1.FormattedValue"
                ],
              statusValue: eachRecord.cr08d_status,
              completedOn: newDate, //.cr08d_completedon,
              percentageCompleted:
                eachRecord[
                  "cr08d_percentagecompleted@OData.Community.Display.V1.FormattedValue"
                ],
              customers: [{ guid: this._emptyGuid }],
              name: eachRecord.cr08d_name,
              startDate: newStartDate,
              applicationType:
                eachRecord[
                  "cr08d_applicationtype@OData.Community.Display.V1.FormattedValue"
                ],
              applicationTypeValue: eachRecord.cr08d_applicationtype,
              criticality:
                eachRecord[
                  "cr08d_criticality@OData.Community.Display.V1.FormattedValue"
                ],
              criticalityValue: eachRecord.cr08d_criticality,
              description: eachRecord.cr08d_description,
              reason: eachRecord.cr08d_reason,
              pastresolutioncomments: eachRecord.cr08d_pastresolutioncomments,
              supplyInfo: supplyInfoData,
            };

            console.log(childRecord);
            newData = modifySubItems(
              newData,
              subItemsField,
              (item) => {
                return item.guid === parentId;
              },
              (subItems) => {
                let newItems = subItems.filter(
                  (each) => each.guid !== this._emptyGuid
                );
                newItems.push(childRecord);
                childGuidArray.push(childRecord.guid);
                return newItems;
              }
            );
          }
        });
        resolve(newData);
      });

      pr.then((newData: any) => {
        console.log(newData);
        this.gridDataCopy = newData;
        this.setState(
          {
            ...this.state,
            data: newData,
          },
          () => {
            parentResolve(childGuidArray);
          }
        );
      });
    });

    // });
    //});
  }

  updateRecordinCRM = async (record: Customer) => {
    let data: any = {
      cr08d_name: record.name,
      cr08d_description: record.description,
      cr08d_pastresolutioncomments: record.pastresolutioncomments,
      cr08d_reason: record.reason,
    };

    if (record.statusValue) {
      data["cr08d_status"] = parseInt(record.statusValue);
    }

    if (record.criticalityValue) {
      data["cr08d_criticality"] = parseInt(record.criticalityValue);
    }

    if (record.applicationTypeValue) {
      data["cr08d_applicationtype"] = parseInt(record.applicationTypeValue);
    }

    if (record.completedOn) {
      data["cr08d_completedon"] = new Date(
        record.completedOn.getFullYear(),
        record.completedOn.getMonth(),
        record.completedOn.getDate()
      );

      console.log(data["cr08d_completedon"]);
    }
    if (record.startDate) {
      data["cr08d_startdate"] = new Date(
        record.startDate.getFullYear(),
        record.startDate.getMonth(),
        record.startDate.getDate()
      )
        .toISOString()
        .split("T")[0];

      console.log(data["cr08d_startdate"]);
    }
    if (record.percentageCompleted) {
      const percentageCompleted = parseInt(
        record.percentageCompleted.toString()
      );
      let completedValue = -1;

      switch (percentageCompleted) {
        case 0:
          completedValue = 132520000;
          break;
        case 25:
          completedValue = 132520001;
          break;
        case 50:
          completedValue = 132520002;
          break;
        case 75:
          completedValue = 132520003;
          break;
        case 100:
          completedValue = 132520004;
          break;
      }
      if (completedValue !== -1)
        data["cr08d_percentagecompleted"] = completedValue;
    }
    await this._context.webAPI.updateRecord(
      "cr08d_customer",
      record.guid,
      data
    );
  };

  deleteRecordFromCRM = async (record: Customer) => {
    await this._context.webAPI.deleteRecord("cr08d_customer", record.guid);
  };

  addChild = (dataItem: Customer) => {
    const newRecord = this.createNewItem();

    this.setState({
      ...this.state,
      inEdit: [...this.state.inEdit, newRecord],
      //expanded: [...state.expanded, dataItem.guid],
      data: modifySubItems(
        this.state.data,
        subItemsField,
        (item) => item.guid === dataItem.guid,
        (subItems) => [newRecord, ...subItems]
      ),
    });
  };

  enterEdit = (dataItem: Customer, field: string) => {
    this.setState({
      ...this.state,
      inEdit: [...this.state.inEdit, extendDataItem(dataItem, subItemsField)],
      editItem: { ...dataItem },
      editItemField: field,
    });
  };

  exitEdit = () => {
    this.setState({
      ...this.state,
      editItem: undefined,
      editItemField: undefined,
    });
  };

  renderers = new Renderers(this.enterEdit, this.exitEdit, editField);

  save = async (dataItem: Customer) => {
    const { isNew, inEdit, ...itemToSave } = dataItem;

    if (typeof itemToSave.status === "object") {
      const dropdownSelectedObj: any = itemToSave.status;
      itemToSave.status = dropdownSelectedObj.text;
      itemToSave.statusValue = dropdownSelectedObj.value;
    }

    await this.updateRecordinCRM(itemToSave);

    this.setState({
      ...this.state,
      data: mapTree(this.state.data, subItemsField, (item) =>
        item.guid === itemToSave.guid ? itemToSave : item
      ),
      inEdit: this.state.inEdit.filter((i) => i.guid !== itemToSave.guid),
    });
  };

  cancel = (editedItem: Customer) => {
    const { inEdit, data } = this.state;
    if (editedItem.isNew) {
      return this.remove(editedItem);
    }

    this.setState({
      ...this.state,
      data: mapTree(data, subItemsField, (item) =>
        item.guid === editedItem.guid
          ? inEdit.find((i) => i.guid === item.guid)
          : item
      ),
      inEdit: inEdit.filter((i) => i.guid !== editedItem.guid),
    });
  };

  remove = async (dataItem: Customer) => {
    var confirmStrings = {
      text: "Are you sure you want to delete this?",
      title: "Confirmation Dialog",
    };
    var confirmOptions = { height: 200, width: 450 };
    this._context.navigation
      .openConfirmDialog(confirmStrings, confirmOptions)
      .then(async (success) => {
        if (success.confirmed) {
          await this.deleteRecordFromCRM(dataItem);
          this.setState({
            ...this.state,
            data: removeItems(
              this.state.data,
              subItemsField,
              (i) => i.guid === dataItem.guid
            ),
            inEdit: this.state.inEdit.filter((i) => i.guid !== dataItem.guid),
          });
        }
      });
  };

  onExpandChange = async (e: TreeListExpandChangeEvent) => {
    const expanded: boolean = !e.value;
    const tree: Customer[] = [...this.state.data];

    if (e.level.length === 4) {
      mapTreeItem(tree, e.level, subItemsField, (item) =>
        extendDataItem(item, subItemsField, { [expandField]: false })
      );
      let newData = modifySubItems(
        this.state.data,
        subItemsField,
        (item) => {
          return item.guid === e.dataItem.guid;
        },
        (subItems) => {
          let emptyChilds: Customer[] = [];
          return emptyChilds;
        }
      );

      this.setState({
        ...this.state,
        data: newData,
      });
    } else {
      mapTreeItem(tree, e.level, subItemsField, (item) =>
        extendDataItem(item, subItemsField, { [expandField]: expanded })
      );

      let expandedVaue: any;

      if (expanded === false) {
        //when collapsed
        expandedVaue = this.state.expanded.filter(
          (guid) => guid !== e.dataItem.guid
        );
      } else {
        if (e.dataItem.customers[0].guid !== this._emptyGuid) {
          e.dataItem.customers = [{ guid: this._emptyGuid }];
        }
        if (e.dataItem.customers[0].guid === this._emptyGuid) {
          await this.getChildDataFromCRM(e.dataItem.guid, e.level);
        }

        //when click on expand icon
        expandedVaue = [...this.state.expanded, e.dataItem.guid];
      }

      this.setState({
        ...this.state,
        expanded: expandedVaue,
      });
    }
  };

  onPageChange = (event: TreeListPageChangeEvent) => {
    const { skip, take } = event;
    this.setState({
      ...this.state,
      skip,
      take,
    });
  };
  onItemChange = (event: TreeListItemChangeEvent) => {
    const field: any = event.field;
    let canPopupbeShown = false;
    let editForbulk: string[] = [];
    let canBulkEditBtnDisable: boolean = false;

    const mtree = mapTree(this.state.data, subItemsField, (item) => {
      if (item.guid === event.dataItem.guid) {
        let ed: any;
        if (field === "status") {
          let percentageCompleted = 0;
          switch (event.value.value) {
            case "132520000":
              percentageCompleted = 0;
              break;
            case "132520001":
              percentageCompleted = 25;
              break;
            case "132520002":
              percentageCompleted = 50;
              break;
            case "132520003":
              percentageCompleted = 75;
              break;
            case "132520004":
              percentageCompleted = 100;
              break;
          }
          if (
            event.value.value === "132520005" ||
            event.value.value === "132520006"
          ) {
            canPopupbeShown = true;
          }
          const nameValue: string = event.dataItem["name"];
          const appTypeValue: string = event.dataItem["applicationType"];
          const reasonValue: string = event.dataItem["reason"];
          const criticalityValue: string = event.dataItem["criticality"];
          const descriptionValue: string = event.dataItem["description"];
          const pastresolutioncommentsValue: string =
            event.dataItem["pastresolutioncomments"];
          const startDateValue: Date = event.dataItem["startDate"];
          const completedOnValue: Date = event.dataItem["completedOn"];

          ed = this.ValidateCell(
            field,
            event.value,
            nameValue,
            item,
            percentageCompleted,
            "name"
          );

          ed = this.ValidateCell(
            field,
            event.value,
            startDateValue,
            ed,
            percentageCompleted,
            "startDate"
          );

          ed = this.ValidateCell(
            field,
            event.value,
            completedOnValue,
            ed,
            percentageCompleted,
            "completedOn"
          );

          ed = this.ValidateCell(
            field,
            event.value,
            appTypeValue,
            ed,
            percentageCompleted,
            "applicationType"
          );

          ed = this.ValidateCell(
            field,
            event.value,
            reasonValue,
            ed,
            percentageCompleted,
            "reason"
          );

          ed = this.ValidateCell(
            field,
            event.value,
            criticalityValue,
            ed,
            percentageCompleted,
            "criticality"
          );
          ed = this.ValidateCell(
            field,
            event.value,
            descriptionValue,
            ed,
            percentageCompleted,
            "description"
          );
          ed = this.ValidateCell(
            field,
            event.value,
            pastresolutioncommentsValue,
            ed,
            percentageCompleted,
            "pastresolutioncomments"
          );
        } else if (
          field === "name" ||
          field === "pastresolutioncomments" ||
          field === "description" ||
          field === "pastresolutioncomments" ||
          field === "reason"
        ) {
          ed = this.ValidateFieldCell(event, ed, field, item);
        } else if (field === "applicationType" || field === "criticality") {
          ed = this.ValidateDropdownCell(event, ed, field, item);
        } else if (field === "checkBoxColumn") {
          ed = extendDataItem(item, subItemsField, { [field]: event.value });
          if (event.value) {
            editForbulk = [...this.state.inEditForBulk, event.dataItem.guid];
          } else {
            editForbulk = this.state.inEditForBulk.filter(
              (guid) => guid !== event.dataItem.guid
            );
          }
          canBulkEditBtnDisable = !(editForbulk.length > 1);
        } else {
          ed = extendDataItem(item, subItemsField, { [field]: event.value });
        }
        return ed;
      }
      return item;
    });
    this.setState({
      ...this.state,
      data: mtree,
      changes: true,
      visibleModelPopup: canPopupbeShown,
      inEditForBulk: editForbulk,
      bulkEditBtndisable: canBulkEditBtnDisable,
    });
  };

  ValidateCell = (
    field: string,
    value: any,
    validateFieldValue: any,
    item: Customer,
    percentageCompleted: number,
    validateFieldName: string
  ) => {
    let isValidationpassed: boolean | undefined = undefined;
    let candisabled: boolean | undefined = undefined;

    if (percentageCompleted === 75 || percentageCompleted === 100) {
      isValidationpassed =
        validateFieldValue === undefined || validateFieldValue.length === 0
          ? false
          : true;
      candisabled = false;
    } else {
      isValidationpassed = true;
      candisabled = true;
    }

    let validationInfo: any = [];
    let obj = {
      fieldName: validateFieldName,
      IsValidationpassed: isValidationpassed,
    };
    if (item.performValidation && item.performValidation.length > 0) {
      const indx = item.performValidation.findIndex(
        (e: any) => e.fieldName === validateFieldName
      );
      if (indx === -1) {
        item.performValidation.push(obj);
      } else {
        item.performValidation[indx] = obj;
      }
      validationInfo = item.performValidation;
    } else {
      validationInfo.push(obj);
    }

    //disable
    let disableInfo: any = [];
    let disableObj = {
      fieldName: validateFieldName,
      canDisabled: candisabled,
    };
    if (item.disableFields && item.disableFields.length > 0) {
      const indx = item.disableFields.findIndex(
        (e: any) => e.fieldName === validateFieldName
      );
      if (indx === -1) {
        item.disableFields.push(disableObj);
      } else {
        item.disableFields[indx] = disableObj;
      }
      disableInfo = item.disableFields;
    } else {
      disableInfo.push(disableObj);
    }
    let ed: any;
    if (field === "status") {
      ed = extendDataItem(item, subItemsField, {
        [field]: value.text, //event.value,
        ["statusValue"]: value.value,
        ["percentageCompleted"]: percentageCompleted,
        ["performValidation"]: validationInfo,
        ["disableFields"]: disableInfo,
      });
    } else if (field === "applicationType") {
      ed = extendDataItem(item, subItemsField, {
        [field]: value.text, //event.value,
        ["applicationTypeValue"]: value.value,
        ["percentageCompleted"]: percentageCompleted,
        ["performValidation"]: validationInfo,
        ["disableFields"]: disableInfo,
      });
    } else if (field === "criticality") {
      ed = extendDataItem(item, subItemsField, {
        [field]: value.text, //event.value,
        ["criticalityValue"]: value.value,
        ["percentageCompleted"]: percentageCompleted,
        ["performValidation"]: validationInfo,
        ["disableFields"]: disableInfo,
      });
    } else {
      ed = extendDataItem(item, subItemsField, {
        [field]: value, //event.value,
        ["percentageCompleted"]: percentageCompleted,
        ["performValidation"]: validationInfo,
        ["disableFields"]: disableInfo,
      });
    }
    return ed;
  };

  addRecord = () => {
    // const newRecord:{id:number,isNew:boolean}  = createNewItem();
    const newRecord: any = this.createNewItem();
    this.setState({
      ...this.state,
      data: [...this.state.data, { ...newRecord }],
      inEdit: [...this.state.inEdit, { ...newRecord }],
    });
  };

  BulkUpdate = async () => {
    // const newRecord:{id:number,isNew:boolean}  = createNewItem();
    // if (this.state.inEdit.length === 0) return;
    let editedRowsGuids: any;

    if (
      this.state.isFromBulkEdit === true &&
      this.state.inEditForBulk.length > 0
    ) {
      editedRowsGuids = this.state.inEditForBulk;
    } else {
      editedRowsGuids = this.state.inEdit;
    }

    if (editedRowsGuids.length === 0) return;
    //if (this.state.editId === undefined || this.state.editId === "") return;

    let editedRowsIds: any = [];
    const editedRecords: any = editedRowsGuids; //this.state.inEdit;
    let foundRecords: Customer[] = [];
    // if (this.state.editId) {
    //   let foundRows = this.FindAndGetDataItemFromTreeByGuid(
    //     this.state.data,
    //     "guid",
    //     this.state.editId
    //   );
    //   if (foundRows.length > 0) foundRecords.push(foundRows[0]);
    // }
    editedRecords.map((e: any) => {
      this.isFound = false;
      this.foundRecord = undefined;
      const { isNew, inEdit, ...itemToSave } = e;
      let rec: Customer | undefined;
      const recordGuid = typeof e === "string" ? e : e.guid;
      for (let index = 0; index < this.state.data.length; index++) {
        const element = this.state.data[index];
        let foundArray = this.FindAndGetDataItemFromTreeByGuid(
          this.state.data,
          "guid",
          recordGuid
        ); // this.findElementInTree(element, e.guid);
        if (foundArray.length > 0) {
          rec = foundArray[0];
          break;
        }
      }
      if (rec) {
        //save(rec);
        foundRecords.push(rec);
      }
      console.log("BulkUpdate ::" + rec?.guid);
    });

    if (foundRecords.length === 0) return;
    let responseText: any;
    try {
      var bulkupdatedData: Customer[] = this.state.data;
      var bulkupdatedEditData: { guid: string; isNew: boolean }[] =
        this.state.inEdit;

      if (foundRecords.length > 0) {
        await new Promise((resolve) => {
          let totalProcessed: number = 0;
          foundRecords.forEach(async (dataItem) => {
            const { isNew, inEdit, ...itemToSave } = dataItem;
            await this.updateRecordinCRM(itemToSave);
            //update child records
            let isfound = false;
            debugger;
            mapTree(this.state.data, "", (item) => {
              if (item.guid === itemToSave.guid) {
                isfound = true;
                itemToSave.customers = item.customers;
              }
              return item;
            });
            if (isfound === false) {
              modifySubItems(
                this.state.data,
                subItemsField,
                (item) => {
                  return item.guid === itemToSave.guid;
                },
                (subItems) => {
                  isfound = true;
                  itemToSave.customers = subItems;
                  return subItems;
                }
              );
            }

            bulkupdatedData = mapTree(
              bulkupdatedData,
              subItemsField,
              (item) => {
                let finalItem =
                  item.guid === itemToSave.guid ? itemToSave : item;
                let extendedItem = extendDataItem(finalItem, subItemsField, {
                  ["IsEditCheckBoxChecked"]: false,
                });
                return extendedItem;
              }
            );
            bulkupdatedEditData = bulkupdatedEditData.filter(
              (i) => i.guid !== itemToSave.guid
            );
            totalProcessed++;
            if (totalProcessed === foundRecords.length) {
              resolve(true);
            }
          });
        });

        this.setState({
          ...this.state,
          data: bulkupdatedData,
          inEdit: bulkupdatedEditData,
          editId: null,
          inEditForBulk: [],
          isFromBulkEdit: false,
          changes: false,
        });
        responseText = "Updated Successfully.";
      } else {
        responseText = "No records to Update.";
      }
    } catch (error) {
      responseText = error;
    }

    var alertStrings = {
      confirmButtonLabel: "Ok",
      text: responseText,
      title: "Update Info",
    };
    var alertOptions = { height: 120, width: 260 };
    this._context.navigation.openAlertDialog(alertStrings, alertOptions).then(
      function (success) {
        console.log("Updated Successfully.");
      },
      function (error) {
        console.log(error.message);
      }
    );
  };

  findElementInTree = (current: Customer, keyId: string) => {
    if (current.guid === keyId) {
      this.isFound = true;
      this.foundRecord = current;
    } else {
      if (this.isFound === false && current.customers) {
        this.findElementInTree(current.customers[0], keyId);
      }
    }

    return this.foundRecord;
  };

  createNewItem = () => {
    const timestamp: number = new Date().getTime();
    const t: Customer = {
      guid: "",
      status: "",
      isNew: true,
      percentageCompleted: 0,
      statusValue: "",
    };
    return { guid: "", isNew: true };
  };

  OnChangeOfDropdown = (e: any, dataItem: any) => {};

  statusDropDownCellEditor = DropDownCellFunc(
    this.OnChangeOfDropdown,
    this.statusDropdownValues
  );

  appTypeDropDownCellEditor = DropDownCellFunc(
    this.OnChangeOfDropdown,
    this.appTypeDropdownValues
  );

  criticalityDropDownCellEditor = DropDownCellFunc(
    this.OnChangeOfDropdown,
    this.criticalityDropdownValues
  );

  startDateCellEditor = DatePickerCell();

  completedOnDateCellEditor = DatePickerCell();

  // toolTipCell = (props: any) => {
  //   debugger;
  //   <Tooltip showTooltip={this.state.showToolTip}/>
  // };
  toolTipCell = (props: any) => {
    return <TootlTipPopup dataItem={props.dataItem} />;
  };

  onChangeOfEditCheckBox = (isChecked: any, recordId: string) => {};
  editCheckBoxCell = (props: any) => {
    return (
      <EditCheckBox
        {...props}
        checkBoxChecked={props.dataItem.IsEditCheckBoxChecked}
        onChangeHandler={this.onChangeOfEditCheckBox}
      />
    );
  };
  columns: Array<TreeListColumnProps | {}> = [
    { cell: this.toolTipCell, width: "50px" },
    {
      field: "checkBoxColumn",
      title: "Bulk Edit",
      cell: this.editCheckBoxCell,
      width: "50px",
    },
    {
      field: "name",
      title: "Name",
      width: "280px",
      editCell: this.textBoxCell,
      expandable: true,
      filterCell: TreeListTextFilter,
    },
    {
      field: "status",
      title: "Status",
      width: "280px",
      editCell: this.statusDropDownCellEditor,
      filterCell: this.dropdownFilter,
    },
    {
      field: "startDate",
      title: "Start Date",
      width: "260px",
      editCell: this.startDateCellEditor,
      filterCell: TreeListDateFilter,
      format: "{0: MM-dd-yyyy}",
    },
    {
      field: "completedOn",
      title: "Completed On",
      width: "260px",
      editCell: this.completedOnDateCellEditor,
      filterCell: TreeListDateFilter,
      format: "{0: MM-dd-yyyy}",
    },
    {
      field: "percentageCompleted",
      title: "% Completed",
      filterCell: TreeListTextFilter,
    },
    {
      field: "applicationType",
      title: "Application Type",
      width: "280px",
      editCell: this.appTypeDropDownCellEditor,
      filterCell: this.appTypeDropdownFilter,
    },
    {
      field: "criticality",
      title: "Criticality",
      width: "250px",
      editCell: this.criticalityDropDownCellEditor,
      filterCell: this.criticalityDropdownFilter,
    },
    {
      field: "reason",
      title: "Reason",
      width: "150px",
      editCell: this.reasonTextBoxCell,
      filterCell: TreeListTextFilter,
    },
    {
      field: "description",
      title: "Description",
      width: "150px",
      editCell: this.descriptionTextBoxCell,
      filterCell: TreeListTextFilter,
    },
    {
      field: "pastresolutioncomments",
      title: "Past Resolution Comments",
      width: "150px",
      editCell: this.pastresolutioncommentsTextBoxCell,
      filterCell: TreeListTextFilter,
    },
    // { cell: this.CommandCell, width: "360px" },
  ];

  // private { data, expanded, inEdit } = this.state;
  handleFilterChange = (event: TreeListFilterChangeEvent) => {
    this.setState({
      ...this.state,
      filter: event.filter,
    });
  };

  handleDropdownFilterChange = (event: filterProps) => {
    this.setState({
      ...this.state,
      filter: event.filter,
      filterDropDownValue: event.dropdownValue,
    });
  };

  handleAppTypeDropdownFilterChange = (event: filterProps) => {
    this.setState({
      ...this.state,
      filter: event.filter,
      filterDropDownValueOfAppType: event.dropdownValue,
    });
  };

  handleCriticalityDropdownFilterChange = (event: filterProps) => {
    this.setState({
      ...this.state,
      filter: event.filter,
      filterDropDownValueOfCriticality: event.dropdownValue,
    });
  };
  processData = () => {
    //getDataFromCRM();
    console.log("processData started");
    let data = this.state.data;
    let filteredData = filterBy(data, this.state.filter, subItemsField);
    console.log("processData end");
    return this.addExpandField(filteredData);
  };

  addExpandField = (dataTree: Customer[]) => {
    const editItemId =
      this.state.editItem !== undefined && this.state.editItem
        ? this.state.editItem.guid
        : null;
    const expanded = this.state.expanded;
    const resultData = mapTree(dataTree, subItemsField, (item) =>
      extendDataItem(item, subItemsField, {
        [expandField]: expanded.includes(item.guid),
        [editField]: item.guid === this.state.editId,
        //item.guid === editItemId ? this.state.editItemField : undefined,
      })
    );
    return resultData;
  };

  saveChanges = () => {
    //.splice(0, employees.length, ...state.data);
    this.setState({
      ...this.state,
      editItem: undefined,
      editItemField: undefined,
      changes: false,
    });
  };

  cancelChanges = () => {
    this.setState({
      ...this.state,
      data: this.gridDataCopy,
      editItem: undefined,
      editItemField: undefined,
      changes: false,
      editId: null,
      isFromBulkEdit: false,
      inEditForBulk: [],
    });
  };

  collapseAll = () => {
    this.setState({
      ...this.state,
      expanded: [],
    });
  };

  bulkEdit = () => {
    debugger;
    console.log("Bulk Edit");
    console.log(this.state.inEditForBulk);
    this.setState({
      showWindow: !this.state.showWindow,
      bulkEditGuids: this.state.inEditForBulk,
    });
  };

  onBulkEditClose = (close: boolean) => {
    this.setState({
      showWindow: close,
    });
  };

  bulkEditOnApply = (dataItem: IBulkEditState) => {
    console.log("bulkEditOnApply fired");
    if (this.state.inEditForBulk && this.state.inEditForBulk.length > 0) {
      let mtree: Customer[] = this.state.data;
      this.state.inEditForBulk.forEach((eachGuid: string) => {
        let guid = eachGuid;
        mtree = mapTree(mtree, subItemsField, (item) => {
          if (item.guid === guid) {
            let ed: any;
            let obj: any = {};
            if (dataItem.applicationType) {
              obj["applicationType"] =
                typeof dataItem.applicationType === "object"
                  ? dataItem.applicationType.text
                  : dataItem.applicationType;
              obj["applicationTypeValue"] =
                typeof dataItem.applicationType === "object"
                  ? dataItem.applicationType.value
                  : dataItem.applicationTypeValue;
            }
            if (dataItem.criticality) {
              obj["criticality"] =
                typeof dataItem.criticality === "object"
                  ? dataItem.criticality.text
                  : dataItem.criticality;
              obj["criticalityValue"] =
                typeof dataItem.criticality === "object"
                  ? dataItem.criticality.value
                  : dataItem.criticalityValue;
            }

            if (dataItem.description) {
              obj["description"] = dataItem.description;
            }
            if (dataItem.pastresolutioncomments) {
              obj["pastresolutioncomments"] = dataItem.pastresolutioncomments;
            }
            if (dataItem.reason) {
              obj["reason"] = dataItem.reason;
            }
            if (dataItem.startDate) {
              obj["startDate"] = dataItem.startDate;
            }
            if (dataItem.completedOnDate) {
              obj["completedOn"] = dataItem.completedOnDate;
            }
            ed = extendDataItem(item, subItemsField, obj);

            return ed;
          }
          return item;
        });
      });

      this.setState({
        data: mtree,
        isFromBulkEdit: true,
        showWindow: false,
      });
    }
  };

  ValidateFieldCell = (
    event: TreeListItemChangeEvent,
    ed: any,
    field: any,
    item: any
  ) => {
    let selectedStatus = "";
    if (typeof event.dataItem["status"] === "object") {
      selectedStatus = event.dataItem["status"].text;
    } else {
      selectedStatus = event.dataItem["status"];
    }
    let percentageCompleted = -1;
    if (selectedStatus === "About to Complete") {
      percentageCompleted = 75;
    } else if (selectedStatus === "Completed") {
      percentageCompleted = 100;
    }
    if (
      selectedStatus === "About to Complete" ||
      selectedStatus === "Completed"
    ) {
      const nameValue = event.value;
      ed = this.ValidateCell(
        field,
        event.value,
        nameValue,
        item,
        percentageCompleted,
        field
      );
    }
    return ed;
  };

  ValidateDropdownCell = (
    event: TreeListItemChangeEvent,
    ed: any,
    field: any,
    item: any
  ) => {
    let selectedStatus = "";
    if (typeof event.dataItem["status"] === "object") {
      selectedStatus = event.dataItem["status"].text;
    } else {
      selectedStatus = event.dataItem["status"];
    }
    let percentageCompleted = -1;
    if (selectedStatus === "About to Complete") {
      percentageCompleted = 75;
    } else if (selectedStatus === "Completed") {
      percentageCompleted = 100;
    }
    if (
      selectedStatus === "About to Complete" ||
      selectedStatus === "Completed"
    ) {
      let nameValue;
      if (typeof event.value === "object") {
        nameValue = event.value.value;
      } else {
        nameValue = event.value;
      }

      ed = this.ValidateCell(
        field,
        event.value,
        nameValue,
        item,
        percentageCompleted,
        field
      );
    }
    return ed;
  };

  private GetDateByYMD(completedOnDateString: string) {
    const tIndex = completedOnDateString.indexOf("T");
    const onlyDate = completedOnDateString.substring(0, tIndex);
    const dateValues = onlyDate.split("-");
    const year: number = parseInt(dateValues[0]);
    const month: number = parseInt(dateValues[1]);
    const day: number = parseInt(dateValues[2]);
    const newDate = new Date(year, month, day);
    return newDate;
  }
  private GetDateByYMDWithoutT(onlyDate: string) {
    const dateValues = onlyDate.split("-");
    const year: number = parseInt(dateValues[0]);
    const month: number = parseInt(dateValues[1]);
    const day: number = parseInt(dateValues[2]);
    const newDate = new Date(year, month, day);
    return newDate;
  }
  toggleDialog = () => {
    this.setState({
      ...this.state,
      visibleModelPopup: !this.state.visibleModelPopup,
      criticality: "",
      reason: "",
      description: "",
      pastresolutioncomments: "",
      anyError: false,
      errorText: "",
    });
  };

  applyTotheRow = () => {
    const criticality = this.state.criticality;
    const description = this.state.description;
    const pastresolutioncomments = this.state.pastresolutioncomments;
    const reason = this.state.reason;
    const recordguid = this.state.editId;

    if (
      criticality !== "" &&
      description &&
      description.length > 0 &&
      pastresolutioncomments &&
      pastresolutioncomments.length > 0 &&
      reason &&
      reason.length > 0
    ) {
      const updatedTree = mapTree(this.state.data, subItemsField, (item) => {
        if (item.guid === recordguid) {
          let criticalityObj: any = criticality;
          const ed = extendDataItem(item, subItemsField, {
            ["criticality"]:
              typeof criticalityObj === "object"
                ? criticalityObj.text
                : criticality,
            ["criticalityValue"]:
              typeof criticalityObj === "object"
                ? criticalityObj.value
                : criticality,
            ["description"]: description,
            ["pastresolutioncomments"]: pastresolutioncomments,
            ["reason"]: reason,
          });
          return ed;
        }
        return item;
      });

      this.setState(
        {
          ...this.state,
          data: updatedTree,
          visibleModelPopup: !this.state.visibleModelPopup,
        },
        () => {
          this.setState({
            ["criticality"]: "",
            ["description"]: "",
            ["pastresolutioncomments"]: "",
            ["reason"]: "",
          });
        }
      );
    } else {
      this.setState({
        ...this.state,
        anyError: true,
        errorText: "Please enter all values to proceed.",
      });
    }
  };
  criticalityChangeOnPopup = (event: DropDownListChangeEvent) => {
    this.setState({
      criticality: event.target.value,
    });
  };

  rowRender = (trElement: any, props: TreeListRowProps) => {
    const rowIndx = props.rowIndex;

    const statusVal = props.dataItem.statusValue;
    const appTypeVal = props.dataItem.applicationTypeValue;

    const green = { backgroundColor: "rgb(55, 180, 0,0.32)" };
    const red = { backgroundColor: "#de4566" };
    const grey = { backgroundColor: "rgb(186, 192, 194, 0.32)" };
    const paleCerulean = { backgroundColor: "#9cc8d9" };
    const casper = { backgroundColor: "#b4b7d9" };
    const lavender = { backgroundColor: "#ab7fb0" };
    const lily = { backgroundColor: "#d4a9ba" };
    //const isEven: any = rowIndx % 2 === 0 ? paleCerulean : grey;
    let rowColor;

    switch (appTypeVal) {
      case "132520000":
      case 132520000:
        rowColor = paleCerulean;
        break;
      case "132520001":
      case 132520001:
        rowColor = casper;
        break;
    }
    // switch (statusVal) {
    //   case "132520000":
    //     rowColor = red;
    //     break;
    //   case "132520001":
    //     rowColor = paleCerulean;
    //     break;
    //   case "132520002":
    //     rowColor = casper;
    //     break;
    //   case "132520003":
    //     rowColor = lavender;
    //     break;
    //   case "132520004":
    //     rowColor = green;
    //     break;
    //   case "132520005":
    //     rowColor = lily;
    //     break;
    //   case "132520006":
    //     rowColor = grey;
    //     break;
    //   default:
    //     break;
    // }
    const trProps: any = { style: rowColor };
    return React.cloneElement(
      trElement,
      { ...trProps },
      trElement.props.children
    );
  };
  render() {
    return (
      <div>
        <TreeList
          style={{ maxHeight: "400px", overflow: "auto" }}
          data={this.processData()}
          editField={editField}
          expandField={expandField}
          subItemsField={subItemsField}
          filter={this.state.filter}
          onFilterChange={this.handleFilterChange}
          pager={TreeListPager}
          onPageChange={this.onPageChange}
          skip={this.state.skip}
          take={this.state.take}
          onItemChange={this.onItemChange}
          onExpandChange={this.onExpandChange}
          onRowClick={this.rowClick}
          columns={this.columns}
          rowRender={this.rowRender}
          // columns={this.columns.map((column: any) => ({
          //   ...column,
          //   editCell:
          //     this.state.editItemField === column.field
          //       ? column.editCell
          //       : undefined,
          // }))}
          // cellRender={this.renderers.cellRender}
          // rowRender={this.renderers.rowRender}
          toolbar={
            <TreeListToolbar>
              {/* <button
              title="Save Changes"
              className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
              onClick={this.saveChanges}
              disabled={!this.state.changes}
            >
              Save Changes
            </button> */}
              <button
                title="Update All Changes"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={() => {
                  this.BulkUpdate();
                }}
                disabled={!this.checkAllValidationsPassed()}
              >
                Update All
              </button>
              <button
                title="Cancel Changes"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={this.cancelChanges}
                disabled={!this.state.changes}
              >
                Cancel Changes
              </button>
              <button
                title="Collapse All"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={this.collapseAll}
              >
                Collapse All
              </button>
              <button
                title="Bulk Edit"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={this.bulkEdit}
                disabled={this.state.bulkEditBtndisable}
              >
                Bulk Edit
              </button>
            </TreeListToolbar>
          }
        />

        {this.state.visibleModelPopup && (
          <Dialog title={"Task Details"} onClose={this.toggleDialog}>
            {/* <p style={{ margin: "25px", textAlign: "center" }}>
              Are you sure you want to continue?
            </p> */}
            <div className="grid-layout-container">
              {this.state.anyError && (
                <div style={{ marginBottom: "5px" }}>
                  <span
                    style={{
                      color: "red",
                      backgroundColor: "yellow",
                      fontSize: "20px",
                    }}
                  >
                    {this.state.errorText}
                  </span>
                </div>
              )}
              <GridLayout
                gap={{ rows: 4, cols: 1 }}
                rows={[
                  { height: 60 },
                  { height: 60 },
                  { height: 60 },
                  { height: 90 },
                  // { height: 660 },
                ]}
                cols={[{ width: 100 }, { width: 390 }]}
              >
                <GridLayoutItem row={1} col={1} style={{ marginTop: "10px" }}>
                  <Label editorId={"Reason"} style={{ fontSize: "20px" }}>
                    Reason:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={1} col={2}>
                  <div>
                    <Input
                      style={{ height: "40px" }}
                      id="Reason"
                      value={this.state.reason}
                      onChange={(e: InputChangeEvent) =>
                        this.setState({ ...this.state, reason: e.value })
                      }
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={2} col={1} style={{ marginTop: "10px" }}>
                  <Label
                    editorId={"Description"}
                    style={{ marginTop: "25px", fontSize: "20px" }}
                  >
                    Description:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={2} col={2}>
                  <div>
                    <Input
                      style={{ height: "40px" }}
                      id="Description"
                      value={this.state.description}
                      onChange={(e: InputChangeEvent) =>
                        this.setState({ ...this.state, description: e.value })
                      }
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={3} col={1} style={{ marginTop: "10px" }}>
                  <Label
                    editorId={"Criticality"}
                    style={{ marginTop: "25px", fontSize: "20px" }}
                  >
                    Criticality:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={3} col={2}>
                  <div>
                    <DropDownList
                      style={{ height: "40px" }}
                      id="Criticality"
                      data={this.criticalityDropdownValues}
                      textField="text"
                      dataItemKey="value"
                      value={this.state.criticality}
                      onChange={this.criticalityChangeOnPopup}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={4} col={1} style={{ marginTop: "10px" }}>
                  <Label
                    editorId={"pastresolutioncomments"}
                    style={{ marginTop: "25px", fontSize: "20px" }}
                  >
                    Past Resolution Comments:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={4} col={2}>
                  <div>
                    <TextArea
                      style={{ height: "90px" }}
                      id="pastresolutioncomments"
                      value={this.state.pastresolutioncomments}
                      rows={4}
                      autoSize={false}
                      onChange={(e: any) =>
                        this.setState({
                          ...this.state,
                          pastresolutioncomments: e.value,
                        })
                      }
                    />
                  </div>
                </GridLayoutItem>
              </GridLayout>
            </div>
            <DialogActionsBar>
              <button
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                onClick={this.toggleDialog}
                style={{ fontSize: "20px" }}
              >
                Cancel
              </button>
              <button
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                onClick={this.applyTotheRow}
                style={{ fontSize: "20px" }}
              >
                Apply to the row
              </button>
            </DialogActionsBar>
          </Dialog>
        )}

        {this.state.showWindow && (
          <BulkEditWindow
            showWindow={this.state.showWindow}
            editRowsGuid={this.state.bulkEditGuids}
            OnClose={this.onBulkEditClose}
            OnApply={this.bulkEditOnApply}
          />
        )}
        {/* <Tooltip element={this.state.element} /> */}
      </div>
    );
  }
}
