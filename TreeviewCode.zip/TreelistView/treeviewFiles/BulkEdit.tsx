import * as React from "react";
// import * as ReactDOM from 'react-dom';
import { Popover, PopoverActionsBar } from "@progress/kendo-react-tooltip";
import { Button } from "@progress/kendo-react-buttons";
import { FaInfoCircle } from "react-icons/fa";
import { Customer, SupplyInfo } from "./interfaces";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { GridLayout, GridLayoutItem } from "@progress/kendo-react-layout";
import {
  Input,
  InputChangeEvent,
  TextArea,
} from "@progress/kendo-react-inputs";
import { Label } from "@progress/kendo-react-labels";
import {
  DropDownList,
  DropDownListChangeEvent,
} from "@progress/kendo-react-dropdowns";
import { DateInput, DatePicker } from "@progress/kendo-react-dateinputs";

interface IBulkEditProps {
  editRowsGuid?: string[];
  showWindow?: boolean;
  OnClose?: any;
  OnApply?: any;
}

export interface IBulkEditState {
  showWindow?: boolean;
  startDate?: Date;
  completedOnDate?: Date;
  applicationType?: any;
  applicationTypeValue?: string;
  reason?: string;
  criticality?: any;
  criticalityValue?: string;
  description?: string;
  pastresolutioncomments?: string;
  showError?: boolean;
}
export default class BulkEditWindow extends React.Component<
  IBulkEditProps,
  IBulkEditState
> {
  private appTypeDropdownValues = [
    { text: "Application Type 1", value: "132520000" },
    { text: "Application Type 2", value: "132520001" },
  ];

  private criticalityDropdownValues = [
    { text: "High", value: "132520000" },
    { text: "Low", value: "132520001" },
    { text: "Medium", value: "132520002" },
  ];

  constructor(props: IBulkEditProps) {
    super(props);
    this.setState({
      showError: false,
    });
  }

  componentDidMount() {
    this.setState({
      showWindow: this.props.showWindow,
    });
  }

  onClick = () => {};

  toggleDialog = () => {
    if (this.props.OnClose) {
      this.props.OnClose(!this.state.showWindow);
    }
    this.setState({
      showWindow: !this.state.showWindow,
    });
  };

  applyTotheRow = () => {
    const canProceed = this.allValidationsPassed();
    this.setState({
      showError: !canProceed,
    });
    if (!canProceed) {
      return;
    }
    if (this.props.OnApply) {
      this.props.OnApply(this.state);
    }
  };

  allValidationsPassed = () => {
    if (
      this.state.applicationType ||
      this.state.completedOnDate ||
      this.state.criticality ||
      this.state.description ||
      this.state.pastresolutioncomments ||
      this.state.reason ||
      this.state.startDate
    ) {
      return true;
    }

    return false;
  };
  render() {
    const rowHeight: number = 35;
    if (this.state && this.state.showWindow) {
      return (
        <div>
          <Dialog title={"Bulk Edit"} onClose={this.toggleDialog}>
            {/* <p style={{ margin: "25px", textAlign: "center" }}>
          Are you sure you want to continue?
        </p> */}
            <div className="grid-layout-container">
              {this.state.showError && (
                <div style={{ marginBottom: "5px" }}>
                  <span
                    style={{
                      color: "red",
                      backgroundColor: "yellow",
                      fontSize: "10px",
                    }}
                  >
                    Please enter all values.
                  </span>
                </div>
              )}
              <GridLayout
                gap={{ rows: 1, cols: 2 }}
                rows={[
                  { height: rowHeight },
                  { height: rowHeight },
                  { height: rowHeight },
                  { height: rowHeight },
                  { height: rowHeight },
                  { height: rowHeight },
                  { height: 90 },
                ]}
                cols={[{ width: 90 }, { width: 390 }]}
              >
                <GridLayoutItem row={1} col={1} style={{ marginTop: "5px" }}>
                  <Label editorId={"Reason"} style={{ fontSize: "10px" }}>
                    Reason:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={1} col={2}>
                  <div>
                    <Input
                      style={{ height: "30px" }}
                      id="Reason"
                      value={this.state.reason}
                      onChange={(e: InputChangeEvent) => {
                        this.setState({ reason: e.value });
                      }}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={2} col={1} style={{ marginTop: "5px" }}>
                  <Label
                    editorId={"Description"}
                    style={{ marginTop: "25px", fontSize: "10px" }}
                  >
                    Description:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={2} col={2}>
                  <div>
                    <Input
                      style={{ height: "30px" }}
                      id="Description"
                      value={this.state.description}
                      onChange={(e: InputChangeEvent) => {
                        this.setState({ description: e.value });
                      }}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={3} col={1} style={{ marginTop: "5px" }}>
                  <Label
                    editorId={"StartDate"}
                    style={{ marginTop: "25px", fontSize: "10px" }}
                  >
                    Start Date:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={3} col={2}>
                  <div>
                    <DatePicker
                      format="MM-dd-yyyy"
                      id="StartDate"
                      value={this.state.startDate}
                      onChange={(e: any) => {
                        this.setState({ startDate: e.value });
                      }}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={4} col={1} style={{ marginTop: "5px" }}>
                  <Label
                    editorId={"CompletedOn"}
                    style={{ marginTop: "25px", fontSize: "10px" }}
                  >
                    Completed On:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={4} col={2}>
                  <div>
                    <DatePicker
                      format="MM-dd-yyyy"
                      id="CompletedOn"
                      onChange={(e: any) => {
                        this.setState({
                          completedOnDate: e.value,
                        });
                      }}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={5} col={1} style={{ marginTop: "5px" }}>
                  <Label
                    editorId={"Criticality"}
                    style={{ marginTop: "25px", fontSize: "10px" }}
                  >
                    Criticality:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={5} col={2}>
                  <div>
                    <DropDownList
                      style={{ height: "30px" }}
                      id="Criticality"
                      data={this.criticalityDropdownValues}
                      textField="text"
                      dataItemKey="value"
                      value={this.state.criticality}
                      onChange={(e: DropDownListChangeEvent) => {
                        this.setState({
                          criticality: e.target.value,
                        });
                      }}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={6} col={1} style={{ marginTop: "5px" }}>
                  <Label
                    editorId={"ApplicationType"}
                    style={{ marginTop: "25px", fontSize: "10px" }}
                  >
                    Application Type:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={6} col={2}>
                  <div>
                    <DropDownList
                      style={{ height: "30px" }}
                      id="Criticality"
                      data={this.appTypeDropdownValues}
                      textField="text"
                      dataItemKey="value"
                      value={this.state.applicationType}
                      onChange={(e: DropDownListChangeEvent) => {
                        this.setState({
                          applicationType: e.target.value,
                        });
                      }}
                    />
                  </div>
                </GridLayoutItem>
                <GridLayoutItem row={7} col={1} style={{ marginTop: "5px" }}>
                  <Label
                    editorId={"pastresolutioncomments"}
                    style={{ marginTop: "25px", fontSize: "10px" }}
                  >
                    Past Resolution Comments:&nbsp;
                  </Label>
                </GridLayoutItem>
                <GridLayoutItem row={7} col={2}>
                  <div>
                    <TextArea
                      style={{ height: "90px" }}
                      id="pastresolutioncomments"
                      rows={4}
                      autoSize={false}
                      value={this.state.pastresolutioncomments}
                      onChange={(e: any) => {
                        this.setState({
                          pastresolutioncomments: e.value,
                        });
                      }}
                    />
                  </div>
                </GridLayoutItem>
              </GridLayout>
            </div>
            <DialogActionsBar>
              <button
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                onClick={this.toggleDialog}
                style={{ fontSize: "10px" }}
              >
                Cancel
              </button>
              <button
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                onClick={this.applyTotheRow}
                style={{ fontSize: "10px" }}
              >
                Apply
              </button>
            </DialogActionsBar>
          </Dialog>
        </div>
      );
    }
    return null;
  }
}
