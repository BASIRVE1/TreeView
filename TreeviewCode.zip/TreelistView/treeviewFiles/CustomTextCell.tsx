import { DropDownList } from "@progress/kendo-react-dropdowns";
import { TreeListTextEditorProps } from "@progress/kendo-react-treelist";
import * as React from "react";
import { Customer } from "./interfaces";
import { Label, Hint, Error } from "@progress/kendo-react-labels";
import { Input } from "@progress/kendo-react-inputs";
import {
  Form,
  Field,
  FormElement,
  FieldWrapper,
  FormRenderProps,
} from "@progress/kendo-react-form";

export interface ITextCellProps extends TreeListTextEditorProps {}

export default function TextCellFunc() {
  return class TextCell extends React.Component<ITextCellProps, {}> {
    render() {
      if (this.props.field) {
        const value = this.props.dataItem[this.props.field];
        if (!this.props.dataItem.inEdit) {
          return <td> {value === null ? "" : value}</td>;
        }

        return (
          <td>
            <Form
              initialValues={{
                Textfield: value,
              }}
              render={(formRenderProps: FormRenderProps) => {
                const uiElement = (
                  //
                  <FormElement>
                    <fieldset className={"k-form-fieldset"}>
                      <Field
                        id={this.props.field}
                        name={"Textfield"}
                        //   label={"Username:"}
                        value={formRenderProps.valueGetter("Textfield")}
                        hint={"Hint: Enter your text here"}
                        // component={(fieldProps) => {
                        //   return this.FormInput(fieldProps, this.props);
                        // }}
                        component={this.FormInput}
                        validator={this.inputValidator}
                        onChange={this.fieldOnChange}
                      />
                    </fieldset>
                  </FormElement>
                );

                return uiElement;
              }}
            />
          </td>
        );
      }
      return null;
    }
    fieldOnChange = async (e: any) => {
      if (this.props.onChange) {
        this.props.onChange({
          dataItem: this.props.dataItem,
          field: this.props.field,
          syntheticEvent: e.syntheticEvent,
          value: e.target.value,
          level: this.props.level,
        });
      }
    };
    inputValidator = (value: any) => {
      if (!value) {
        return "This field is required.";
      } else {
        return "";
      }
      // (!value ? "Please enter a text." : "");
    };
    onMouseEnter = (e: any) => {
      console.log("mouse enter fired");
    };
    FormInput = (fieldRenderProps: any) => {
      const {
        validationMessage,
        touched,
        label,
        id,
        valid,
        disabled,
        hint,
        type,
        optional,
        max,
        value,
        ...others
      } = fieldRenderProps;
      console.log(this.props);

      let validField = true;
      let disableField = false;
      const fieldValue =
        this.props.field && this.props.dataItem[this.props.field];
      //disable
      if (
        this.props.dataItem.disableFields &&
        this.props.dataItem.disableFields.length > 0
      ) {
        const indx: any = this.props.dataItem.disableFields.findIndex(
          (e: any) => e.fieldName === this.props.field
        );

        if (indx !== -1) {
          disableField = this.props.dataItem.disableFields[indx].canDisabled;
        }
      }

      if (
        this.props.dataItem.performValidation &&
        this.props.dataItem.performValidation.length > 0
      ) {
        const indx: any = this.props.dataItem.performValidation.findIndex(
          (e: any) => e.fieldName === this.props.field
        );

        if (indx !== -1) {
          validField =
            this.props.dataItem.performValidation[indx].IsValidationpassed;
        }
      }
      let showValidationMessage =
        fieldValue === undefined || (fieldValue === "" && validationMessage); // touched && validationMessage;
      const showHint = !showValidationMessage && hint;
      const hindId = showHint ? `${id}_hint` : "";
      const errorId = showValidationMessage ? `${id}_error` : "";

      let selectedText = "";
      if (typeof this.props.dataItem.status === "object") {
        selectedText = this.props.dataItem.status.text;
      } else {
        selectedText = this.props.dataItem.status;
      }
      if (
        selectedText === "About to Complete" ||
        selectedText === "Completed"
      ) {
        showValidationMessage = fieldValue === undefined || fieldValue === "";
      } else {
        showValidationMessage = false;
      }
      return (
        <FieldWrapper>
          <div className={"k-form-field-wrap"} onMouseEnter={this.onMouseEnter}>
            <Input
              valid={validField}
              type={type}
              id={id}
              disabled={disableField}
              maxlength={max}
              ariaDescribedBy={`${hindId} ${errorId}`}
              value={fieldValue}
              onMouseEnter={this.onMouseEnter.bind(this)}
              onMouseOver={this.onMouseEnter}
              {...others}
            />
            {showValidationMessage && (
              <Error id={errorId}>{validationMessage}</Error>
            )}
          </div>
        </FieldWrapper>
      );
    };
  };
}
