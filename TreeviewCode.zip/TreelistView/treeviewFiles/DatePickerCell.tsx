import { DatePicker } from "@progress/kendo-react-dateinputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { TreeListDateEditorProps, TreeListTextEditorProps } from "@progress/kendo-react-treelist";
import * as React from "react";
import { Customer } from "./interfaces";

export interface IDateProps extends TreeListDateEditorProps {
}

export default function DateCellFunc()
 {
  return class DateCell extends React.Component<IDateProps, {}> {
    handleChange(e: any) {
      //dropdownChange(e, this.props.dataItem);
      if (this.props.onChange) {
        this.props.onChange({
          dataItem: this.props.dataItem,
          field: this.props.field,
          syntheticEvent: e.syntheticEvent,
          value: e.target.value,
          level: this.props.level,
        });
      }
    }
    render() {
      if (this.props.field) {
        // const dropdownValues = [
        //   { text: "Not Started", value: "132520000" },
        //   { text: "Started", value: "132520001" },
        //   { text: "In Progress", value: "132520002" },
        //   { text: "About to Complete", value: "132520003" },
        //   { text: "Completed", value: "132520004" },
        // ];
        //const dropdownValues = statusDropdownValues;
        const value = this.props.dataItem[this.props.field];

        if (!this.props.dataItem.inEdit) {
          debugger;
          return (
            <td>
              {" "}
              {value === null ? "" : this.props.dataItem[this.props.field]}
            </td>
          );
        }

        // const foundIndex = dropdownValues.findIndex((each) => {
        //   const selectedVal: any = value;
        //   if (typeof selectedVal === "object")
        //     return each.text === selectedVal.text;
        //   else return each.text === value;
        // });

        // const doprdownVal = foundIndex !== -1 ? dropdownValues[foundIndex] : "";

        let allValidationPassed = true;
        const validationArray = this.props.dataItem.performValidation;
        if (validationArray && validationArray.length > 0) {
          const indx = this.props.dataItem.performValidation.findIndex(
            (e: any) =>
              e.fieldName === this.props.field && e.IsValidationpassed === false
          );
          allValidationPassed = indx === -1;
        }

        let canDisabled = false;
        const disableArray = this.props.dataItem.disableFields;
        if (disableArray && disableArray.length > 0) {
          const indx = this.props.dataItem.disableFields.findIndex(
            (e: any) => e.fieldName === this.props.field
          );
          canDisabled =
            indx === -1
              ? false
              : this.props.dataItem.disableFields[indx].canDisabled;
        }
let todayDate=new Date();
        return (
          <td>
            <DatePicker format="MM-dd-yyyy" defaultValue={todayDate} onChange={this.handleChange.bind(this)} disabled={canDisabled}/>
          </td>
        );
      }
      return null;
    }
  };
}
