import * as React from "react";
import {
  DropDownList,
} from "@progress/kendo-react-dropdowns";
import { TreeListFilterCellProps } from "@progress/kendo-react-treelist/dist/npm/interfaces/TreeListFilterCellProps";
import { TreeListFilterChangeEvent } from "@progress/kendo-react-treelist";

interface dropdownProps extends TreeListFilterCellProps {
  defaultItem: string;
  data: string[];
  handleFilterChangeFunc: any;
  valueText: string;
}

export interface filterProps extends TreeListFilterChangeEvent {
  dropdownValue: string;
}
const DropDownFilter = (props: dropdownProps) => {
  const { field, data, defaultItem, onFilterChange } = props;
  const [dropdownValue, setdropdownValue] = React.useState(props.valueText);

  const onChange = (event: any) => {
    const value = event.value;

    const filter: any[] = props.filter ? [...props.filter] : []; //[...props.filter];
    const currentFilterIndex: number = filter.findIndex(
      (f) => f.field === field
    );

    if (currentFilterIndex !== -1) {
      filter.splice(currentFilterIndex, 1);
    }

    if (value !== defaultItem) {
      filter.push({ value, field, operator: "eq" });
    }
    let df: any = undefined;
    let er: filterProps = {
      field: props.field ? props.field : "",
      filter: filter,
      syntheticEvent: df,
      nativeEvent: df,
      target: df,
      dropdownValue: value,
    };
    props.handleFilterChangeFunc(er);
  };

  return (
    <DropDownList
      data={data}
      onChange={onChange}
      id="dropdownState"
      value={props.valueText}
      defaultItem="Select.."
    />
  );
};

export default DropDownFilter;
