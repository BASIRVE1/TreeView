import * as React from "react";
// import * as ReactDOM from 'react-dom';
import { Popover, PopoverActionsBar } from "@progress/kendo-react-tooltip";
import { Button } from "@progress/kendo-react-buttons";
import { Checkbox } from "@progress/kendo-react-inputs";
import { FaInfoCircle } from "react-icons/fa";
import { Customer, SupplyInfo } from "./interfaces";
import { TreeListBooleanEditorProps } from "@progress/kendo-react-treelist";

interface IEditCheckBoxProps extends TreeListBooleanEditorProps {
  checkBoxChecked: boolean;
  onChangeHandler: any;
}

export default class EditCheckBox extends React.Component<
  IEditCheckBoxProps,
  {}
> {
  onChange = (e: any) => {
    if (this.props.onChangeHandler) {
      this.props.onChangeHandler(e.target.value, this.props.dataItem.guid);
    }
    if (this.props.onChange) {
      const di: Customer = this.props.dataItem;
      di.IsEditCheckBoxChecked = e.target.value;

      this.props.onChange({
        dataItem: di,
        field: this.props.field,
        syntheticEvent: e.syntheticEvent,
        value: e.target.value,
        level: this.props.level,
      });
    }
  };

  render() {
    return (
      <td>
        <div>
          <Checkbox
            style={{ width: "20px", height: "20px" }}
            onChange={this.onChange}
            value={this.props.checkBoxChecked}
          />
        </div>
      </td>
    );
  }
}
