import * as React from "react";
// import * as ReactDOM from 'react-dom';
import { Popover, PopoverActionsBar } from "@progress/kendo-react-tooltip";
import { Button } from "@progress/kendo-react-buttons";
import { Checkbox } from "@progress/kendo-react-inputs";
import { FaInfoCircle } from "react-icons/fa";
import { Customer, SupplyInfo } from "./interfaces";
import { Label } from "@progress/kendo-react-labels";

interface ITooltipProps {
  dataItem: Customer;
}

export default class TootlTipPopup extends React.Component<ITooltipProps, {}> {
  anchor: any = React.createRef();
  state = { show: false, callout: true };

  componentDidMount() {
    this.setState({ show: false });
  }

  onClick = () => {
    this.setState({ show: !this.state.show });
  };
  onMouseEnter = (e: any) => {
    this.setState({ show: !this.state.show });
  };
  onMouseLeave = (e: any) => {
    this.setState({ show: !this.state.show });
  };

  render() {
    const { show } = this.state;
    let supplyInfoDataView: any;
    let supplyInfoCount: number = 0;

    let filteredRows = this.props.dataItem.supplyInfo?.filter(
      (si: SupplyInfo) => {
        return si.guid !== undefined;
      }
    );

    if (filteredRows && filteredRows.length > 0) {
      {
        supplyInfoCount = filteredRows.length;

        const sortedSupplyInfo = filteredRows.sort(
          (s1: SupplyInfo, s2: SupplyInfo) => {
            if (s1.supplyInfoModifiedOn && s2.supplyInfoModifiedOn) {
              return (
                s2.supplyInfoModifiedOn.valueOf() -
                s1.supplyInfoModifiedOn.valueOf()
              );
            }
            return 0;
          }
        );
        let rows: any = [];

        const sortedData =
          sortedSupplyInfo.length >= 2
            ? sortedSupplyInfo.slice(0, 2)
            : sortedSupplyInfo;

        sortedData.forEach((eachSI: SupplyInfo) => {
          rows.push(
            <tr className="tooltiptr">
              <td className="tooltiptd">
                {eachSI.approvalDate &&
                  eachSI.approvalDate.toLocaleDateString()}
              </td>
              <td className="tooltiptd">{eachSI.crNumber}</td>
            </tr>
          );
        });

        if (rows.length > 0) {
          supplyInfoDataView = (
            <table className="tooltiptable">
              <tr className="tooltiptr">
                <th>Approval Date</th>
                <th>CR Number</th>
              </tr>
              {rows}
            </table>
          );
        } else {
          supplyInfoDataView = <div>No data found</div>;
        }
      }
    } else {
      supplyInfoDataView = <div>No data found</div>;
    }

    return (
      <td>
        <div>
          {/* <Button
            style={{
              display: "inline-block",
              border: "none",
              width: "50px",
              minHeight: "55px",
              maxHeight: "100%",
            }}
            onClick={this.onClick}
            //disabled={false}
            ref={this.anchor}
            onMouseEnter={this.onMouseEnter}
            onMouseLeave={this.onMouseLeave}
          >
            {/* <FaInfoCircle style={{ width: "40px", height: "20px" }} /> */}
            {/* {supplyInfoCount}
          </Button> */} 
            {/* anchor={this.anchor.current && this.anchor.current.element} */}

          <div
            style={{ fontSize: "20px" }}
            onMouseEnter={this.onMouseEnter}
            onMouseLeave={this.onMouseLeave}
            ref={this.anchor}
          >
            {supplyInfoCount}
          </div>
          <Popover
            show={show}
            anchor={this.anchor.current}
            callout={true}
            margin={true ? undefined : { vertical: 0, horizontal: 0 }}
            title={"Supply Info"}
            onPosition={(e) => console.log(e)}
            position="right"
          >
            {supplyInfoDataView}
          </Popover>
        </div>
      </td>
    );
  }
}
