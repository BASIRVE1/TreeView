import * as React from "react";
import { Customer } from "./interfaces";

export default function TreeviewCommandsCell(
  enterEdit: { (dataItem: Customer): void; (arg0: any): void },
  remove: { (dataItem: Customer): void; (arg0: any): void },
  save: { (dataItem: Customer): void; (arg0: any): void },
  cancel: { (editedItem: Customer): void; (arg0: any): void },
  addChild: { (dataItem: Customer): void; (arg0: any): void },
  editField: string
) {
  // eslint-disable-next-line react/display-name
  return class extends React.Component {
    render() {
      //debugger;
      const row: any = {
        ...this.props,
      };
      const dataItem = row["dataItem"];
      //const { dataItem } = this.props;
      if (dataItem[editField]) {
        const JsxView = (
          <td>
            <button
              className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base gridCommandButtons"
              onClick={() => save(dataItem)}
            >
              {dataItem.isNew ? "Add" : "Update"}
            </button>
            <button
              className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base gridCommandButtonsForRemove"
              onClick={() => cancel(dataItem)}
            >
              {dataItem.isNew ? "Discard" : "Cancel"}
            </button>
          </td>
        );
        return JsxView;
      } else {
        const jsxView = (
          <td>
            {/* <button
            className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
            onClick={() => addChild(dataItem)}
          >
            Add Employee
          </button> */}
            <button
              className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base gridCommandButtons"
              onClick={() => enterEdit(dataItem)}
            >
              Edit
            </button>
            <button
              className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base gridCommandButtonsForRemove"
              onClick={() => remove(dataItem)}
            >
              Delete
            </button>
          </td>
        );

        return jsxView;
      }
    }
  };
}
