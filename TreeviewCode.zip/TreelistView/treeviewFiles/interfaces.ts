import { FilterDescriptor, SortDescriptor } from "@progress/kendo-data-query";

export interface Customer {
    guid: string,
    status?: string,
    statusValue?: string,
    completedOn?: Date,
    percentageCompleted?: number,
    customers?: Customer[],
    inEdit?: boolean,
    isNew?: boolean,
    name?: string,
    startDate?: Date,
    applicationType?: string,
    applicationTypeValue?: string,
    reason?: string,
    criticality?: string,
    criticalityValue?: string,
    description?: string,
    pastresolutioncomments?: string,
    performValidation?: [{ fieldName: string, IsValidationpassed: boolean }],
    disableFields?: [{ fieldName: string, canDisabled: boolean }],
    modelPopupData?: [{ reason: string, criticality: string, description: string, pastresolutioncomments: string }]
    supplyInfo?: SupplyInfo[],
    IsEditCheckBoxChecked?: boolean,
}

export interface SupplyInfo {
    guid?: string,
    supplyInfoModifiedOn?: Date,
    supplyInfoComments?: string,
    parentGuid?: string,
    approvalDate?:Date,
    crNumber?:number
}


